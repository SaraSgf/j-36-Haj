﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;


namespace HAKATHON
{
    public partial class Hajj : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            SqlConnection CONN = new SqlConnection();
            CONN.ConnectionString = ConfigurationManager.ConnectionStrings["Graduate_ProjectConnectionString"].ConnectionString;
            DataTable dt = new DataTable();
            //--------------------------------

                CONN.Open();
                SqlCommand cmd = new SqlCommand("SELECT Graduation_Year as Name, COUNT([ID]) AS Total FROM Arabic GROUP BY Graduation_Year", CONN);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                CONN.Close();
                Chart1.Visible = true;
            


            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }


            Chart1.Series[0].Points.DataBindXY(x, y);
            Chart1.Series[0].ChartType = SeriesChartType.Bar;
            Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
            //Chart1.Legends[0].Enabled = true;

        }
    }
}